---
layout: page
title: About
---

<!-- Note no title because it is provided in the frontmatter, above -->

This is the base about page. Below are some sections commonly found in edition about pages. 

* Table of Contents
{:toc}

## Editorial Policy

How were materials chosen? What decisions were made (e.g. correcting misspellings, leaving misslellings in place, adding contextual notes)? 

## Project History

What led to this project? What influences have there been?

## People

List all the people that helped with the project and their roles

## Use Statement

Are materials public domain? Do you have permission to distribute if not? Would you liek to apply a creative commons or other license to included essays and other paratext? 
